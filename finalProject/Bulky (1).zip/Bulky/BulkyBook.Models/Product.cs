﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BulkyBook.Models
{
    public class Product
    {
        public int Id { get; set; }
        [Required]
        
        [ValidateNever]
        public string ImageUrl { get; set; }
        public string Customer { get; set; }
        [Required]
        public string ProjectName { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public DateOnly StartDate { get; set; }
        [Required]
        public DateOnly EndDate { get; set; }
        [Required]
        public string ProjectManager { get; set; }

        /*[Range(1, 10000)]
        [Display(Name = "List Price")]
        public double EndDate { get; set; }
        [Required]
        [Range(1, 10000)]
        [Display(Name = "Price for 1-50")]*/
        

       /* [Required]
        [Range(1, 10000)]
        [Display(Name = "Price for 51-100")]*/
        /*public double Price50 { get; set; }

        

        [Required]
        [Display(Name = "Category")]
        public int CategoryId { get; set; }
        [ForeignKey("CategoryId")]
        [ValidateNever]
        public Category Category { get; set; }

        [Required]
        [Display(Name ="Cover Type")]
        public int CoverTypeId { get; set; }
        [ValidateNever]
        public CoverType CoverType { get; set; }*/
    }
}
