﻿using BulkyBook.DataAccess.Repository.IRepository;
using BulkyBook.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BulkyBook.DataAccess.Repository
{
	public class ProjectRequirementRepository:Repository<ProjectRequirement>,IProjectRequirementRepository
	{
        private ApplicationDbContext _db;

        public ProjectRequirementRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }


        public void Update(ProjectRequirement obj)
        {
            var objFromDb = _db.Project.FirstOrDefault(u => u.Id == obj.Id);
            if (objFromDb != null)
            {
                objFromDb.CoverTypeId = obj.CoverTypeId;
                objFromDb.ProjectName = obj.ProjectName;
                objFromDb.Description = obj.Description;
                objFromDb.StartDate = obj.StartDate;
                objFromDb.EndDate = obj.EndDate;
                objFromDb.ProjectManager = obj.ProjectManager;
                /*objFromDb.SubmissionDate = obj.SubmissionDate;
                objFromDb.Status = obj.Status;*/



                //objFromDb.CoverTypeId = obj.CoverTypeId;

            }
        }
    }
}
