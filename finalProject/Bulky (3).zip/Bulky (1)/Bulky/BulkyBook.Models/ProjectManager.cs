﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BulkyBook.Models
{
    public class ProjectManager
    {
        [Key] public int Id { get; set; }

        [Display(Name = "ProjectManager Name")][Required][MaxLength(50)] public string Name { get; set; }
        [Display(Name = "Specification")][Required][MaxLength(50)] public string Specification { get; set; }
        [Display(Name = "Email")][Required][MaxLength(50)] public string Email { get; set; }
        [Display(Name = "Mobile")][Required][MaxLength(11)] public string Mobile { get; set; }
    }
}


