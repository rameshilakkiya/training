﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BulkyBook.Models
{
    public class Project
    {
        public int Id { get; set; }
        [Required]
        public int CoverTypeId { get; set; }
        
        [ForeignKey("CoverTypeId")]
        [ValidateNever]
        public CoverType CoverType { get; set; }
        public string ProjectName { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public DateTime StartDate { get; set; }
        [Required]
        
        public DateTime EndDate { get; set; }
        [Required]
        
        public string ProjectManager { get; set; }
        [Required]

        public DateTime SubmissionDate { get; set; }
        [Required]

        public string Status { get; set; }










    }
}
