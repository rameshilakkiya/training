﻿using BulkyBook.DataAccess.Repository.IRepository;
using BulkyBook.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;



namespace BulkyBook.DataAccess.Repository
{
    public class ProjectManagerRepository : Repository<ProjectManager>, IProjectManagerRepository
    {
        private ApplicationDbContext _db;



        public ProjectManagerRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }




        public void Update(ProjectManager obj)
        {
            _db.ProjectManager.Update(obj);
        }

        public void Update(IProjectManagerRepository obj)
        {
            throw new NotImplementedException();
        }
    }
}


