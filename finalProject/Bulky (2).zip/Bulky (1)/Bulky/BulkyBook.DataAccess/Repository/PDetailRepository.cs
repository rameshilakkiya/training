﻿using BulkyBook.DataAccess.Repository.IRepository;
using BulkyBook.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BulkyBook.DataAccess.Repository
{
    public class PDetailRepository : Repository<PDetail>, IPDetailRepository
    {
        private ApplicationDbContext _db;

        public PDetailRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }


        public void Update(PDetail obj)
        {
            var objFromDb = _db.PDetails.FirstOrDefault(u => u.Id == obj.Id);
            if (objFromDb != null)
            {
                objFromDb.ProjectId = obj.ProjectId;
                objFromDb.CoverTypeId = obj.CoverTypeId;
                objFromDb.JobTitle = obj.JobTitle;
                objFromDb.SkillSet = obj.SkillSet;
                objFromDb.Experience = obj.Experience;
                objFromDb.Months = obj.Months;
                objFromDb.StartDate = obj.StartDate;
                objFromDb.EndDate = obj.EndDate;
                objFromDb.Resources = obj.Resources;


                //objFromDb.CoverTypeId = obj.CoverTypeId;

            }
        }
    }
}

