﻿var dataTable;

$(document).ready(function () {
    loadDataTable();
});

function loadDataTable() {
    dataTable = $('#tblData').DataTable({
        "ajax": {
            "url": "/Admin/Project/Details/GetAll1"
        },
        "columns": [
            { "data": "projectId", "width": "15%" },
            { "data": "coverTypeId", "width": "15%" },
            { "data": "jobTitle", "width": "15%" },
            { "data": "skillSet", "width": "15%" },
            { "data": "experience", "width": "15%" },
            { "data": "months", "width": "15%" },
            { "data": "startDate", "width": "15%" },
            { "data": "endDate", "width": "15%" },
            { "data": "resources", "width": "15%" },

            {
                "data": "id",
                "render": function (data) {
                    return `
                        
                        <div class="w-75 btn-group" role="group">
                        <a href="/Admin/Project/Details?id=${data}"
                        class="btn btn-primary mx-2"> <i class="bi bi-pencil-square"></i></a>
                      
					</div>
                        `
                },
                "width": "15%"
            }
        ]
    });
}

function Delete(url) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: url,
                type: 'DELETE',
                success: function (data) {
                    if (data.success) {
                        dataTable.ajax.reload();
                        toastr.success(data.message);
                    }
                    else {
                        toastr.error(data.message);
                    }
                }
            })
        }
    })
}